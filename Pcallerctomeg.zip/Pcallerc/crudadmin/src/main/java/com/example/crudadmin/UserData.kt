package com.example.crudadmin

data class UserData(val name: String? = null, val operator: String? = null,
                    val location: String? = null,val phone: String? = null){

}
